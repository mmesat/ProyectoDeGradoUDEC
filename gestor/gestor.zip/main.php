﻿<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/html40/loose.dtd">
<html>
  <head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="author" content="CIETIC01">
    <meta name="generator" content="SWiSH Max3 (2009.11.30) www.swishzone.com">
    <meta name="description" content="">
    <meta name="keywords" content="al, bienvenido, de, gestor, home, proyectos">
    <!-- text used in the movie -->
    <!-- al, bienvenido, de, gestor, home, proyectos -->
    <!-- Creado con SWiSH Max - Flash con sencillez - www.swishzone.com -->

<style type="text/css">
/*<![CDATA[*/
html, body
{
    margin: 0;
    padding: 0;
    height: 100%;
}
object
{
    vertical-align: top;
}
/*]]>*/
.entrada {
	font-family: "Courier New", Courier, monospace;
	font-size: 12px;
	font-weight: bold;
	color: #000;
}
</style>
  </head>
  <body bgcolor="#FAF5B4">
    <center>
      <p>
        <object
        classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
        codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,79,0"
        id="main"
        width="780" height="290"
      >
          <param name="movie" value="main.swf">
          <param name="bgcolor" value="#FAF5B4">
          <param name="quality" value="high">
          <param name="seamlesstabbing" value="false">
          <param name="allowscriptaccess" value="samedomain">
          <embed
          type="application/x-shockwave-flash"
          pluginspage="http://www.adobe.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"
          name="main"
          width="780" height="290"
          src="main.swf"
          bgcolor="#FAF5B4"
          quality="high"
          seamlesstabbing="false"
          allowscriptaccess="samedomain"
        >
            <noembed>
            </noembed>
          </embed>
        </object>
      </p>
      <p>&nbsp;</p>
    </center>
    <form id="form1" name="form1" method="post" action="entrada.php">
<table width="353" border="3" align="center">
  <tr>
    <td width="80" class="entrada">Usuario</td>
    <td width="327"><input name="nombre" type="text" id="nombre" size="20" maxlength="20" /></td>
  </tr>
  <tr>
    <td class="entrada">Contraseña</td>
    <td><input type="password" name="contrasena" id="contrasena" /></td>
  </tr>
</table>
<table width="353" border="0" align="center">
  <tr>
    <td width="83">&nbsp;</td>
    <td width="260"><div align="right">
  <input type="submit" name="Submit" value="Ingresar" />
</div></td>
  </tr>
</table>
<p>&nbsp;</p>
<blockquote>
	<blockquote>
    <blockquote>
	<blockquote>
    <blockquote>
	<blockquote>
    <blockquote>
      <blockquote>
        <blockquote>&nbsp;</blockquote>
</blockquote>
</blockquote>
</blockquote>
</blockquote>
</blockquote>
</blockquote>
</blockquote>
</blockquote>
</form> 
    
</body>
</html>
