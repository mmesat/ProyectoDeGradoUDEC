<? 
$user=$_POST['nombre'];
$pasword= $_POST['contrasena'];
//conecto con la base de datos 
$conn = mysql_connect("localhost","root",""); 
//selecciono la BBDD 
mysql_select_db("gestor",$conn); 

//Sentencia SQL para buscar un usuario con esos datos 
$ssql = "SELECT * FROM usuario WHERE nombre='$user' and contrasena='$pasword'";
 
//Ejecuto la sentencia 
$rs = mysql_query($ssql,$conn)or die( "Error en $ssql: " . mysql_error() ); 

//vemos si el usuario y contraseña es váildo 
//si la ejecución de la sentencia SQL nos da algún resultado 

//es que si que existe esa conbinación usuario/contraseña 
$row = mysql_fetch_array($rs);
if ((mysql_num_rows($rs)!=0)&&(($row['id_rol']) == 1000)){
    //usuario y contraseña válidos 
    //defino una sesion y guardo datos 
    session_start(); 
    session_register("autentificado"); 
    $autentificado = "SI"; 
    header ("Location: administrar/index.html"); 
}
else { 
	if ((mysql_num_rows($rs)!=0)&&(($row['id_rol']) >= 2000)){
    //usuario y contraseña válidos 
    //defino una sesion y guardo datos 
    session_start(); 
    session_register("autentificado"); 
    $autentificado = "SI"; 
    header ("Location: user/index.html"); 
}
    else{//si no existe le mando otra vez a la portada 
    header("Location: main.php?errorusuario=si"); 
	}

} 

mysql_free_result($rs); 
mysql_close($conn);
echo $user;
echo $pasword; 
?> 
</head>

<body>
</body>
</html>